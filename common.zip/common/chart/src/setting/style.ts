const utilities = () => `
  .w-input-sm {
    width: 60px !important;
  }
  .w-input-md {
    width: 88px !important;
  }
  .jimu-input.wrapper-overflow-hidden .input-wrapper {
    overflow: hidden;
  }
`
export default utilities
