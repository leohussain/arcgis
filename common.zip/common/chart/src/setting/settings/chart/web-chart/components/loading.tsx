import { styled } from 'jimu-theme'
import { Loading as _Loading } from 'jimu-ui'

export const Loading = styled(_Loading)({ zIndex: 1 })
