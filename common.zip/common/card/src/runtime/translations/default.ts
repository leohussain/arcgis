export default {
  _layout_REGULAR_label: 'Regular',
  _layout_HOVER_label: 'Hover',
  _layout_DEFAULT_label: 'Default',
  applyTo: 'Apply to {status}',
  isolate: 'Isolate',
  linkedToAnd: 'Linked to {where1} and {where2}',
  linkedTo: 'Linked to {where}',
  placeHolderTip: 'Please select a card template.',
  showSelected: 'Show selection',

  _widgetLabel: 'Card'
}
