export default {
  wayOfAddingData: 'Way of adding data',
  selectFromAccount: 'Select from account',
  inputUrl: 'Input URL',
  uploadFiles: 'Upload files',
  emptyListMessage: 'Empty list message',
  defaultPlaceholderText: 'There is currently no added data.',
  curateACollection: 'Curate a collection',
  allowRenaming: 'Allow renaming',
  allowRemoval: 'Allow removal'
}
